const translate = require('@vitalets/google-translate-api');


const express = require('express')
const bodyParser = require('body-parser')

const app = express()
const port = 3000

app.set('view engine', 'ejs')

const urlencodedParser = bodyParser.urlencoded({ extended: false })

app.get('/', (req, res) => {
    res.render('index')
})

app.post('/', urlencodedParser, (req, res) => {
    // res.json(req.body.enString)
    translate(req.body.enString, { from: 'en', to: 'es' })
        .then(text => {
            // console.log(text.text);  // Hola mundo
            res.json(text.text)
        })
        .catch(err => {
            console.log(err)
        });
})

app.listen(port, () => console.info(`App listening on port:${port}`))